import { Redirect } from 'expo-router'
import React from 'react'

const App = () => {
  return <Redirect href="/home"/>
    // <SafeAreaView className='mt-10 ml-10'>
    //   <Text style = {{fontFamily: 'WorkSans-Black'}} className='text-3xl text-primary'> Hello, World! </Text>
    //   <Text style = {{fontFamily: 'WorkSans-Black'}} className='text-3xl text-secondary'> Hello, World! </Text>
    //   <Text style = {{fontFamily: 'WorkSans-Black'}} className='text-3xl text-secondary-100'> Hello, World! </Text>
    //   <Text style = {{fontFamily: 'WorkSans-Black'}} className='text-3xl text-secondary-200'> Hello, World! </Text>
    //   <Text style = {{fontFamily: 'WorkSans-Black'}} className='text-3xl text-terciary'> Hello, World! </Text>
    //   <StatusBar style="dark" />

    //   <Link href="/products" style={{ fontFamily: 'WorkSans-Medium' }}>
    //     <Text className='text-lg text-blue-500 mt-5'> Go to Products Screen </Text>
    //   </Link>
    // </SafeAreaView>
  
}

export default App