import { Link } from 'expo-router'
import React from 'react'
import { Text, View } from 'react-native'

const ProductsScreen = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text> ProductsScreen </Text>
      <Link href="/" style={{ fontFamily: 'WorkSans-Medium' }}>
        <Text className='text-lg text-blue-500 mt-5'> Go back to Home </Text>
      </Link>
    </View>
  )
}

export default ProductsScreen